import React from 'react';
import { object } from 'prop-types';

//import './style.scss';

Modal.propTypes = {
  children: object,
};

function Modal(props) {
  return <div className="modal-wrapper">{props.children}</div>;
}

export default Modal;
