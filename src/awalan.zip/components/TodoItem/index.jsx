import React, { useState } from 'react';
import { string, bool, func } from 'prop-types';
import Modal from '../Modal';

TodoItem.propTypes = {
  id: string,
  title: string,
  isCompleted: bool,
  onTodoDelete: func,
  onToggleTodoComplete: func,
};

function TodoItem(props) {
  const [isOpenModal, setOpenModal] = useState(false);

  const { id, title, isCompleted, onTodoDelete, onToggleTodoComplete } = props;

  return (
    <div className={isCompleted ? 'todo-item--completed' : 'todo-item'}>
      <div className="todo-title">{title}</div>
      <div className="todo-actions">
        <button className="todo-complete" onClick={onToggleTodoComplete(id)}>
          {isCompleted ? 'Un-complete' : 'Complete'}
        </button>
        <button className="todo-delete" onClick={() => setOpenModal(!isOpenModal)}>
          Delete
        </button>
      </div>
      {isOpenModal && (
        <Modal>
          <div>Yakin kah di deletee?</div>
          <button onClick={onTodoDelete(id)}>Yakin</button>
          <button onClick={() => setOpenModal(!isOpenModal)}>No</button>
        </Modal>
      )}
    </div>
  );
}

export default TodoItem;
