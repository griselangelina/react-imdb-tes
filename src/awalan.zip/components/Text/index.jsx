import React from 'react';
import { string, func } from 'prop-types';

const Text = (props) => {
  Text.propTypes = {
    value: string,
    onInputChange: func,
    onAddTodo: func,
  };

  const { value, onInputChange, onAddTodo } = props;

  return (
    <form onSubmit={onAddTodo}>
      <input className="input" value={value} onChange={onInputChange} />
    </form>
  );
};

export default Text;
